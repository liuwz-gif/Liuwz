<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<body>
<h2>作业15：用户注册</h2>
<form action="/JSP_Quiz2/register" method="post">
    用户名：<input name="username"><br>
    密码：<input name="password" type="password"><br>
    性别：<input type="radio" name="gender" value="男" checked>男
          <input type="radio" name="gender" value="女">女<br>
    <input type="submit" value="提交注册">
</form>
</body>
</html>