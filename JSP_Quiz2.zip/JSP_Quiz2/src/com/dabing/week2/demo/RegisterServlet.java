package com.dabing.week2.demo;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class RegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");

        PrintWriter out = response.getWriter();
        out.println("<h2>作业15：注册信息获取成功</h2>");
        out.println("用户名："+username+"<br>");
        out.println("密码："+password+"<br>");
        out.println("性别："+gender);
        out.close();
    }
}